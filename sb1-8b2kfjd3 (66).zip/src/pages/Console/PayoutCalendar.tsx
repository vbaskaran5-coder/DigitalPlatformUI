import React from 'react';

const PayoutCalendar: React.FC = () => {
  return (
    <div className="px-6">
      <h2 className="text-lg font-medium text-white">Payout Calendar</h2>
      <p className="text-gray-400 mt-4">Functionality coming soon...</p>
    </div>
  );
};

export default PayoutCalendar;